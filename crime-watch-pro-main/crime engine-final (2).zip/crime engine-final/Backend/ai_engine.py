# ai_engine.py
import pandas as pd
import numpy as np
from config import CONTEXT_SIGNATURES, FRAUD_WEIGHTS, COMMAND_PROTOCOLS

class CrimeAnalyzer:
    def __init__(self, filepath):
        self.filepath = filepath
        self.df = None
        self.context = "GENERAL"
        self.mapping = {}

    def load_and_process(self):
        # 1. Load
        try:
            if self.filepath.endswith('.csv'): self.df = pd.read_csv(self.filepath)
            else: self.df = pd.read_excel(self.filepath)
        except Exception as e: return f"Error: {e}"

        # 2. Detect Context
        full_text = self.df.astype(str).sum().str.cat(sep=' ').lower() + " " + " ".join([str(c).lower() for c in self.df.columns])
        
        self.context = "PROPERTY_THEFT" # Default
        for ctx, keywords in CONTEXT_SIGNATURES.items():
            if any(k in full_text for k in keywords):
                self.context = ctx
                break
        print(f"🧠 AI: Context Locked -> {self.context}")

        # 3. Map Columns
        cols = self.df.columns
        self.mapping = {'Location': None, 'Metrics': []}
        
        # Smart Location Finder
        for c in cols:
            if any(k in str(c).lower() for k in ['area', 'state', 'district', 'city']):
                self.mapping['Location'] = c
                break
        
        # Smart Metric Finder
        for c in cols:
            if pd.api.types.is_numeric_dtype(self.df[c]) and 'year' not in str(c).lower():
                self.mapping['Metrics'].append(c)

        if not self.mapping['Location']: return "Error: No Location Column Found"

        # 4. Calculate Risk (The Math)
        self.df['Risk_Score'] = 0
        self.df['Total_Impact'] = 0
        
        if self.context == "SERIOUS_FINANCIAL_FRAUD":
            for col in self.mapping['Metrics']:
                weight = 1
                for key, val in FRAUD_WEIGHTS.items():
                    if key in str(col).lower(): weight = val; break
                self.df[col] = self.df[col].fillna(0)
                self.df['Risk_Score'] += self.df[col] * weight
                self.df['Total_Impact'] += self.df[col]
        else:
            for col in self.mapping['Metrics']:
                self.df[col] = self.df[col].fillna(0)
                self.df['Risk_Score'] += self.df[col]
                self.df['Total_Impact'] += self.df[col]

        # 5. Aggregate & Normalize
        report = self.df.groupby(self.mapping['Location']).agg({
            'Risk_Score': 'sum', 'Total_Impact': 'sum'
        }).reset_index()
        
        max_score = report['Risk_Score'].max()
        report['Normalized_Risk'] = (report['Risk_Score'] / max_score * 100) if max_score > 0 else 0
        report = report.sort_values('Normalized_Risk', ascending=False)

        # 6. Assign Tactical Orders
        def get_order(risk, loc):
            proto = COMMAND_PROTOCOLS.get(self.context, COMMAND_PROTOCOLS["DEFAULT"])
            if risk > 80: return proto["CRITICAL"].format(location=loc)
            elif risk > 50: return proto["HIGH"].format(location=loc)
            elif risk > 20: return proto["MEDIUM"].format(location=loc)
            return proto["LOW"].format(location=loc)

        report['AI_Command'] = report.apply(lambda x: get_order(x['Normalized_Risk'], x[self.mapping['Location']]), axis=1)
        
        return report, self.mapping['Location']