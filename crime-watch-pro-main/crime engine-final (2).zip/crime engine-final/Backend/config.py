# ==============================================================================
#  🚔 CRIME ANALYTICS SYSTEM V5.0 - CONFIGURATION
# ==============================================================================

# 1. CRIME SIGNATURES (AI SENSORS)
CRIME_SIGNATURES = {
    "SERIOUS_FINANCIAL_FRAUD": {
        "keywords": ["fraud", "cheating", "scam", "embezzlement", "money laundering", "assets", "crore", "economic offence", "loss"],
        "severity_weight": 1.5
    },
    "CRIME_AGAINST_WOMEN": {
        "keywords": ["rape", "dowry", "sexual harassment", "molestation", "women", "girl", "trafficking", "pocso"],
        "severity_weight": 2.5
    },
    "CUSTODIAL_DEATH": {
        "keywords": ["custody", "lockup", "police station", "magistrate", "torture", "death in custody", "human rights"],
        "severity_weight": 2.0
    },
    "VIOLENT_CRIME": {
        "keywords": ["murder", "homicide", "shootout", "gang", "weapon", "kill", "stab", "riot", "assault"],
        "severity_weight": 1.8
    },
    "PROPERTY_THEFT": {
        "keywords": ["theft", "burglary", "stolen", "robbery", "vehicle", "loot"],
        "severity_weight": 1.0
    }
}

# 2. SEVERITY WEIGHTS (MATH LOGIC)
WEIGHT_PROTOCOLS = {
    "FINANCIAL_LOSS_WEIGHTS": {
        "Loss_Above_100_Crores": 1000, "Loss_50_100_Crores": 500, "Loss_10_25_Crores": 100, "Loss_1_10_Crores": 50
    },
    "CRIME_AGAINST_WOMEN_WEIGHTS": {
        "Rape": 100, "Gang_Rape": 150, "Dowry_Death": 80
    },
    "VIOLENT_CRIME_WEIGHTS": {
        "Murder": 100, "Riots": 50, "Kidnapping": 70
    },
    "CUSTODIAL_WEIGHTS": {
        "Death_in_Police_Custody": 500, "Death_in_Judicial_Custody": 200
    }
}

# 3. TACTICAL COMMANDS (DYNAMIC SOPs)
TACTICAL_COMMANDS = {
    "SERIOUS_FINANCIAL_FRAUD": {
        "DEFCON_1": "🔴 CRITICAL: IMMEDIATE CBI RAID IN {location}. SEIZE ASSETS WORTH ₹{impact:,.0f} CR. BLOCK INT'L TRANSFERS.",
        "DEFCON_2": "🟠 HIGH: FORENSIC AUDIT OF TOP FIRMS IN {location}. SUSPECTED LOSS: ₹{impact:,.0f} CR. FREEZE ACCOUNTS.",
        "DEFCON_3": "🟡 MEDIUM: MONITOR HIGH-VALUE TRANSACTIONS IN {location}. TOTAL EXPOSURE: ₹{impact:,.0f} CR.",
        "DEFCON_4": "🟢 LOW: ISSUE COMPLIANCE NOTICE TO BANKS IN {location}. ROUTINE CHECK."
    },
    "CRIME_AGAINST_WOMEN": {
        "DEFCON_1": "🔴 URGENT SOP: DEPLOY 'SHE-TEAMS' IN PLAIN CLOTHES AT {location}. MAPPING OF DARK SPOTS REQUIRED. (SEVERITY: {impact})",
        "DEFCON_2": "🟠 HIGH ALERT: ESTABLISH 'WOMEN HELP DESKS' AT ALL {location} STATIONS. INCREASE CCTV NEAR SCHOOLS.",
        "DEFCON_3": "🟡 ACTION: CONDUCT SENSITIZATION DRIVES IN {location}.",
        "DEFCON_4": "🟢 ROUTINE: INCREASE FOOT PATROL IN MARKETS OF {location}."
    },
    "VIOLENT_CRIME": {
        "DEFCON_1": "🔴 CRITICAL: DEPLOY RAPID ACTION FORCE (RAF) TO {location}. IMPOSE SECTION 144 CRPC.",
        "DEFCON_2": "🟠 HIGH: ACTIVATE INFORMER NETWORK IN {location}. CONDUCT COMBING OPERATIONS.",
        "DEFCON_3": "🟡 ACTION: INCREASE NIGHT PATROLS (22:00-05:00) IN {location}.",
        "DEFCON_4": "🟢 ROUTINE: COMMUNITY POLICING MEETING IN {location}."
    },
    "CUSTODIAL_DEATH": {
        "DEFCON_1": "🔴 ALERT: JUDICIAL MAGISTRATE INQUIRY (SEC 176 CRPC) INITIATED IN {location}. SUSPEND SHO PENDING INVESTIGATION.",
        "DEFCON_2": "🟠 HIGH: PRESERVE LOCK-UP CCTV FOOTAGE & GD ENTRIES AT {location}.",
        "DEFCON_3": "🟡 ACTION: INSPECT LOGBOOKS OF {location} POLICE STATION.",
        "DEFCON_4": "🟢 ROUTINE: HUMAN RIGHTS SOP TRAINING FOR STAFF."
    },
    "DEFAULT": {
        "DEFCON_1": "🔴 CRITICAL: MAX SECURITY ALERT IN {location}.",
        "DEFCON_2": "🟠 HIGH: ELEVATED PATROLS IN {location}.",
        "DEFCON_3": "🟡 MEDIUM: INCREASED SURVEILLANCE.",
        "DEFCON_4": "🟢 LOW: STANDARD MONITORING."
    }
}

# 4. STRATEGIC ANALYSIS TEMPLATES (THE NEW FEATURE)
STRATEGIC_ANALYSIS_TEMPLATES = {
    "SERIOUS_FINANCIAL_FRAUD": {
        "HIGH_RISK": "INTELLIGENCE SUMMARY: Analysis indicates a systemic failure in corporate governance and banking oversight mechanisms. The high volume of high-value losses (>₹100 Cr) suggests coordinated insider involvement and money laundering networks. Immediate forensic auditing is required to prevent capital flight.",
        "MODERATE_RISK": "INTELLIGENCE SUMMARY: Detected irregularities in mid-sized financial transactions. The data points to procedural lapses in KYC compliance and loan collateral verification.",
        "LOW_RISK": "INTELLIGENCE SUMMARY: Isolated incidents of financial misconduct detected. Likely due to individual malfeasance rather than organized syndicates."
    },
    "CRIME_AGAINST_WOMEN": {
        "HIGH_RISK": "INTELLIGENCE SUMMARY: Critical breakdown in safety infrastructure detected. The frequency of incidents correlates with inadequate surveillance (Dark Spots) and low police visibility. Pattern suggests predatory behavior targeting vulnerable demographics.",
        "MODERATE_RISK": "INTELLIGENCE SUMMARY: Emerging hotspot for gender-based offenses. Data suggests a need for increased community policing and sensitization drives.",
        "LOW_RISK": "INTELLIGENCE SUMMARY: Routine safety protocols appear effective, though sporadic incidents require continued vigilance."
    },
    "VIOLENT_CRIME": {
        "HIGH_RISK": "INTELLIGENCE SUMMARY: Volatile situation detected. The escalation in violent incidents suggests gang warfare or communal unrest. Intelligence points to an influx of illegal arms.",
        "MODERATE_RISK": "INTELLIGENCE SUMMARY: Localized spikes in aggression. Likely driven by socio-economic friction or localized turf wars.",
        "LOW_RISK": "INTELLIGENCE SUMMARY: Violence levels within standard deviation. Standard law and order maintenance sufficient."
    },
    "CUSTODIAL_DEATH": {
        "HIGH_RISK": "INTELLIGENCE SUMMARY: ALARMING TREND. The cluster of custodial deaths indicates potential abuse of power and non-adherence to DK Basu Guidelines.",
        "MODERATE_RISK": "INTELLIGENCE SUMMARY: Concerning lapses in prisoner safety protocols. Review of medical screening procedures for detainees is recommended.",
        "LOW_RISK": "INTELLIGENCE SUMMARY: Isolated incident requiring standard magisterial review. No systemic pattern detected."
    },
    "DEFAULT": {
        "HIGH_RISK": "INTELLIGENCE SUMMARY: Critical instability detected in this sector. Immediate intervention required.",
        "MODERATE_RISK": "INTELLIGENCE SUMMARY: Emerging threats detected. Preemptive measures recommended.",
        "LOW_RISK": "INTELLIGENCE SUMMARY: Situation normal. Standard protocols active."
    }
}

# 5. GEOSPATIAL INTELLIGENCE (COORDINATE DB)
GEO_INTELLIGENCE = {
    "andhra pradesh": [15.9129, 79.7400], "arunachal pradesh": [28.2180, 94.7278],
    "assam": [26.2006, 92.9376], "bihar": [25.0961, 85.3131],
    "chhattisgarh": [21.2787, 81.8661], "goa": [15.2993, 74.1240],
    "gujarat": [22.2587, 71.1924], "haryana": [29.0588, 76.0856],
    "himachal pradesh": [31.1048, 77.1734], "jharkhand": [23.6102, 85.2799],
    "karnataka": [15.3173, 75.7139], "kerala": [10.8505, 76.2711],
    "madhya pradesh": [22.9734, 78.6569], "maharashtra": [19.7515, 75.7139],
    "manipur": [24.6637, 93.9063], "meghalaya": [25.4670, 91.3662],
    "mizoram": [23.1645, 92.9376], "nagaland": [26.1584, 94.5624],
    "odisha": [20.9517, 85.0985], "punjab": [31.1471, 75.3412],
    "rajasthan": [27.0238, 74.2179], "sikkim": [27.5330, 88.5122],
    "tamil nadu": [11.1271, 78.6569], "telangana": [18.1124, 79.0193],
    "tripura": [23.9408, 91.9882], "uttar pradesh": [26.8467, 80.9462],
    "uttarakhand": [30.0668, 79.0193], "west bengal": [22.9868, 87.8550],
    "delhi": [28.7041, 77.1025], "chandigarh": [30.7333, 76.7794],
    "jammu & kashmir": [33.7782, 76.5762], "ladakh": [34.1526, 77.5770],
    "puducherry": [11.9416, 79.8083], "dadra & nagar haveli": [20.1809, 73.0169],
    "lakshadweep": [10.5667, 72.6417], "daman & diu": [20.4283, 72.8397]
}
# [ADD THIS TO THE BOTTOM OF config.py]

# 6. DETERRENCE PHYSICS (SIMULATION ENGINE)
# This defines how much "Physical Patrols" actually reduce specific crimes.
# 1.0 = Patrols stop it completely.
# 0.1 = Patrols have almost no effect (e.g., Cyber/Fraud).

DETERRENCE_PHYSICS = {
    "PROPERTY_THEFT": 0.85,           # Very High: Police presence stops thieves.
    "VIOLENT_CRIME": 0.70,            # High: Patrols prevent riots/street fights.
    "CRIME_AGAINST_WOMEN": 0.60,      # Medium: Helps in public spaces, less in domestic.
    "CUSTODIAL_DEATH": 0.95,          # Very High: Surveillance/Checks stop this.
    "SERIOUS_FINANCIAL_FRAUD": 0.10,  # Low: Street cops can't stop bank fraud.
    "NARCOTICS_TRAFFICKING": 0.50,    # Medium: Checkposts help, but supply chains run deep.
    "DEFAULT": 0.50
}
# [ADD THIS TO config.py]

# 7. TACTICAL BASES (DEPLOYMENT HUBS)
# The system calculates routes starting from these HQs.
TACTICAL_BASES = {
    "NORTH_COMMAND": [28.6139, 77.2090],      # New Delhi (RAF HQ)
    "SOUTH_COMMAND": [12.9716, 77.5946],      # Bangalore (CRPF Base)
    "WEST_COMMAND": [19.0760, 72.8777],       # Mumbai (QRT Base)
    "EAST_COMMAND": [22.5726, 88.3639],       # Kolkata (RAF Base)
    "CENTRAL_COMMAND": [23.2599, 77.4126],    # Bhopal (Police Academy)
    "CYBER_HQ": [17.3850, 78.4867],           # Hyderabad (Cyber Dome)
    "COASTAL_GUARD": [13.0827, 80.2707]       # Chennai
}
# [ADD THIS TO config.py]

# 8. SHIFT PROFILES (WORKFORCE OPTIMIZATION)
# Defines the percentage of force needed per shift based on crime type.
# Format: [Morning (08-16), Evening (16-00), Night (00-08)]
SHIFT_PROFILES = {
    "SERIOUS_FINANCIAL_FRAUD": [0.70, 0.20, 0.10], # Mostly Day work (Banks/Offices)
    "CRIME_AGAINST_WOMEN":     [0.20, 0.50, 0.30], # Evening commute is critical
    "VIOLENT_CRIME":           [0.10, 0.30, 0.60], # Mostly Night activity
    "PROPERTY_THEFT":          [0.10, 0.20, 0.70], # Deep Night (Burglary)
    "NARCOTICS_TRAFFICKING":   [0.20, 0.40, 0.40], # Evening/Night mix
    "CUSTODIAL_DEATH":         [0.33, 0.33, 0.33], # 24/7 Vigilance required
    "DEFAULT":                 [0.33, 0.33, 0.33]  # Standard Rotation
}
