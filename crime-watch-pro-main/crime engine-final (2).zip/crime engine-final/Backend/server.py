from flask import Flask, request, jsonify
from flask_cors import CORS
import os
import pandas as pd
from system_main import CrimeAnalysisEngine, DataIngestionUnit, DashboardGenerator

app = Flask(__name__)
# Allow All IPs to connect
CORS(app, resources={r"/*": {"origins": "*"}})

@app.route('/api/analyze', methods=['POST'])
def analyze_crime():
    print(f"🔔 Request received...")
    
    if 'file' not in request.files: return jsonify({"error": "No file"}), 400
    
    file = request.files['file']
    filename = f"temp_{file.filename}"
    file.save(filename)

    try:
        # 1. RUN AI ENGINE
        print("⚙️ Running AI Engine...")
        ingest = DataIngestionUnit(filename)
        if ingest.load_dataset():
            ingest.sanitize_columns()
            
            engine = CrimeAnalysisEngine(ingest.clean_data)
            engine.detect_context(); engine.map_columns(); engine.calculate_risk()
            engine.calculate_temporal_trends(); engine.calculate_shifts()
            engine.run_anomaly_detection(); engine.run_nlp_topic_modeling()
            engine.run_network_analysis()
            
            # 2. GENERATE HTML VIEWS
            print("🎨 Generating HTML Trinity...")
            viz = DashboardGenerator(engine)
            
            # A. MAP
            viz.build_map("temp_map.html")
            with open("temp_map.html", "r", encoding="utf-8") as f: map_html = f.read()

            # B. REPORT
            report_html = f"""
            <html><body style="font-family: sans-serif; padding: 40px; background: #f8fafc;">
                <div style="background: white; padding: 30px; border-radius: 10px; max-width: 800px; margin: auto; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
                    <h1 style="color: #1a365d; border-bottom: 2px solid #e2e8f0; padding-bottom: 10px;">📄 Strategic Mission Report</h1>
                    <div style="background: #eff6ff; padding: 15px; border-radius: 6px; margin: 20px 0;">
                        <strong>⚠️ Threat Assessment:</strong><br>{engine.strategic_assessment}
                    </div>
                    <h3>🔍 Detected Themes</h3>
                    <p>{', '.join(engine.nlp_themes)}</p>
                    <h3>📊 Operational Metrics</h3>
                    <ul>
                        <li><b>Anomaly Count:</b> {int(engine.anomaly_count)}</li>
                        <li><b>Context:</b> {engine.context}</li>
                    </ul>
                </div>
            </body></html>
            """

            # C. SIMULATION
            sim_data = engine.report_data.sort_values(by='Risk_Index', ascending=False).head(10)
            rows = ""
            for _, row in sim_data.iterrows():
                rows += f"<tr><td style='padding:8px;'>{row.get('Location','Zone')}</td><td style='padding:8px;'>{row.get('Risk_Index',0):.1f}</td><td style='padding:8px;'>{row.get('Predicted_Crime','N/A')}</td></tr>"

            sim_html = f"""
            <html><body style="font-family: monospace; padding: 20px; background: #111; color: #0f0;">
                <h1 style="border-bottom: 1px solid #0f0;">🕹️ TACTICAL SIMULATION DECK</h1>
                <p>> Target Context: {engine.context}</p>
                <p>> Simulation Status: ACTIVE</p>
                <table style="width: 100%; border: 1px solid #333; margin-top: 20px; color: #fff;">
                    <tr style="background: #333; color: #0f0;"><th style='padding:8px; text-align:left;'>ZONE</th><th style='padding:8px; text-align:left;'>RISK</th><th style='padding:8px; text-align:left;'>PREDICTION</th></tr>
                    {rows}
                </table>
            </body></html>
            """

            return jsonify({
                "success": True,
                "map_html": map_html,
                "report_html": report_html,
                "simulation_html": sim_html,
                "context": engine.context,
                "anomalies": int(engine.anomaly_count),
                "trend": engine.trend_status,
                "shift_roster": engine.shift_split,
                "data": engine.report_data.fillna(0).to_dict(orient='records')
            })

    except Exception as e:
        print(f"❌ Error: {e}")
        return jsonify({"error": str(e)}), 500
    finally:
        if os.path.exists(filename): os.remove(filename)
        if os.path.exists("temp_map.html"): os.remove("temp_map.html")

if __name__ == '__main__':
    app.run(debug=True, port=5000, host='0.0.0.0')