# dashboard.py
import tkinter as tk
from tkinter import filedialog
import os
import webbrowser
import folium
from folium.plugins import HeatMap
from ai_engine import CrimeAnalyzer
from config import GEO_DATABASE

def generate_tactical_map(df, location_col):
    """
    Generates a Professional Heatmap & Marker Map.
    """
    print("🗺️ GENERATING TACTICAL MAP...")
    
    # 1. Create Base Map (Centered on India)
    m = folium.Map(location=[20.59, 78.96], zoom_start=5, tiles='CartoDB dark_matter')
    
    heat_data = []
    
    for _, row in df.iterrows():
        loc_name = str(row[location_col]).lower().strip()
        risk = row['Normalized_Risk']
        impact = row['Total_Impact']
        command = row['AI_Command']
        
        # 2. EXACT COORDINATE LOOKUP (No Randomization)
        coords = GEO_DATABASE.get(loc_name)
        
        # Try fuzzy match if exact match fails (e.g. "Delhi State" vs "Delhi")
        if not coords:
            for k, v in GEO_DATABASE.items():
                if k in loc_name or loc_name in k:
                    coords = v
                    break
        
        if coords and risk > 1: # Only plot relevant data
            # Add to Heatmap
            heat_data.append([coords[0], coords[1], risk])
            
            # Determine Color
            color = '#ff0000' if risk > 80 else '#ffaa00' if risk > 50 else '#00ff00'
            
            # Create Popup
            popup_html = f"""
            <div style="font-family: Arial; width: 250px;">
                <h4 style="margin:0;">{str(row[location_col]).upper()}</h4>
                <hr>
                <b>RISK SCORE:</b> {risk:.1f}%<br>
                <b>TOTAL IMPACT:</b> {int(impact)}<br>
                <br>
                <b style="color:{color}">{command}</b>
            </div>
            """
            
            # Add Marker
            folium.CircleMarker(
                location=coords,
                radius=risk/10 + 5, # Size based on risk
                color=color,
                fill=True,
                fill_color=color,
                fill_opacity=0.7,
                popup=folium.Popup(popup_html, max_width=300)
            ).add_to(m)

    # 3. Add Heat Layer
    if heat_data:
        HeatMap(heat_data, radius=25, blur=15).add_to(m)

    # 4. Save
    output = "tactical_map_view.html"
    m.save(output)
    return os.path.abspath(output)

def main():
    print("\n🕵️ STARTING CRIME ANALYTICS SUITE V2.0")
    
    root = tk.Tk(); root.withdraw(); root.attributes('-topmost', True)
    file_path = filedialog.askopenfilename(title="SELECT DATASET")
    
    if file_path:
        engine = CrimeAnalyzer(file_path)
        report_df, loc_col = engine.load_and_process()
        
        if isinstance(report_df, str):
            print(report_df) # Error
        else:
            # 1. Show Data Table in Console
            print(f"\n📊 ANALYSIS COMPLETE: {len(report_df)} ZONES MAPPED")
            print(report_df[[loc_col, 'Normalized_Risk', 'AI_Command']].head(10).to_string(index=False))
            
            # 2. Generate Map
            map_path = generate_tactical_map(report_df, loc_col)
            print(f"\n✅ MAP GENERATED: {map_path}")
            webbrowser.open(f"file://{map_path}")

if __name__ == "__main__":
    main()