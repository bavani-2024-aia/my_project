# ==============================================================================
#  🚔 CRIME ANALYTICS SYSTEM V23.0 - DEPLOYMENT EDITION (PKL EXPORT)
# ==============================================================================
#  FEATURES:
#  1. LOGIC: V16 Clean Network (MST), NLP, Anomaly Detection.
#  2. REPORT: V16 Full Detailed HTML Report.
#  3. MAP: V21 "Glassmorphism" HUD overlaid on the V16 Operational Map.
#  4. EXPORT: Generates 'tactical_brain.pkl' for model deployment.
# ==============================================================================

import pandas as pd
import numpy as np
import os
import webbrowser
import tkinter as tk
from tkinter import filedialog, simpledialog, messagebox
import folium
from folium.plugins import HeatMap, AntPath
import matplotlib.pyplot as plt
import requests
import json
import time
import pickle  # <--- REQUIRED FOR PKL FILE

# IMPORT ADVANCED AI STACK
try:
    from sklearn.ensemble import IsolationForest
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.decomposition import NMF
    from sklearn.metrics.pairwise import cosine_similarity
    import networkx as nx 
except ImportError:
    print("❌ CRITICAL ERROR: Please run 'pip install networkx scikit-learn'")
    exit()

try:
    from config import (
        CRIME_SIGNATURES, WEIGHT_PROTOCOLS, TACTICAL_COMMANDS, 
        GEO_INTELLIGENCE, STRATEGIC_ANALYSIS_TEMPLATES, 
        DETERRENCE_PHYSICS, TACTICAL_BASES, SHIFT_PROFILES
    )
except ImportError:
    print("❌ CRITICAL ERROR: Update 'config.py' with all sections!")
    exit()

# ==============================================================================
#  MODULE A: DATA INGESTION
# ==============================================================================
class DataIngestionUnit:
    def __init__(self, filepath):
        self.filepath = filepath
        self.raw_data = None
        self.clean_data = None
    def load_dataset(self):
        try:
            if self.filepath.endswith('.csv'): self.raw_data = pd.read_csv(self.filepath)
            elif self.filepath.endswith(('.xls', '.xlsx')): self.raw_data = pd.read_excel(self.filepath)
            return True
        except: return False
    def sanitize_columns(self):
        self.clean_data = self.raw_data.copy()
        self.clean_data.columns = [str(c).strip().replace(" ", "_").replace(".", "") for c in self.clean_data.columns]
        return self.clean_data

# ==============================================================================
#  MODULE B: HYBRID ANALYSIS ENGINE
# ==============================================================================
class CrimeAnalysisEngine:
    def __init__(self, dataframe):
        self.df = dataframe
        self.context = "UNKNOWN"
        self.location_col = None
        self.year_col = None
        self.metric_cols = []
        self.report_data = None
        self.trend_data = None
        self.trend_status = "STABLE"
        self.total_records = 0
        self.strategic_assessment = ""
        self.sim_strength = 0
        self.sim_deterrence = 0
        self.shift_split = [0.33, 0.33, 0.33]
        self.anomaly_count = 0
        self.nlp_themes = []
        self.graph_links = [] 

    def detect_context(self):
        self.total_records = len(self.df)
        corpus = " ".join(self.df.columns).lower() + " " + self.df.astype(str).sum().str.cat(sep=" ").lower()
        best_match = "DEFAULT"; max_hits = 0
        for ctx, sig in CRIME_SIGNATURES.items():
            hits = sum(1 for k in sig['keywords'] if k in corpus)
            if hits > max_hits: max_hits = hits; best_match = ctx
        self.context = best_match
        print(f"🧠 CONTEXT: {self.context}")

    def map_columns(self):
        for c in self.df.columns:
            if any(k in c.lower() for k in ['area', 'state', 'district', 'city', 'zone']): self.location_col = c; break
        for c in self.df.columns:
            if 'year' in c.lower(): self.year_col = c; break
        for c in self.df.columns:
            if pd.api.types.is_numeric_dtype(self.df[c]) and 'year' not in c.lower(): self.metric_cols.append(c)

    def calculate_risk(self):
        self.df['Risk_Score'] = 0.0; self.df['Total_Impact'] = 0.0
        protocol = {}
        if self.context == "SERIOUS_FINANCIAL_FRAUD": protocol = WEIGHT_PROTOCOLS["FINANCIAL_LOSS_WEIGHTS"]
        elif self.context == "CRIME_AGAINST_WOMEN": protocol = WEIGHT_PROTOCOLS["CRIME_AGAINST_WOMEN_WEIGHTS"]
        elif self.context == "VIOLENT_CRIME": protocol = WEIGHT_PROTOCOLS["VIOLENT_CRIME_WEIGHTS"]
        elif self.context == "CUSTODIAL_DEATH": protocol = WEIGHT_PROTOCOLS["CUSTODIAL_WEIGHTS"]

        for col in self.metric_cols:
            weight = 1.0
            for k, v in protocol.items():
                if k.lower() in col.lower(): weight = v
            self.df[col] = self.df[col].fillna(0)
            self.df['Risk_Score'] += self.df[col] * weight
            self.df['Total_Impact'] += self.df[col]

        agg_dict = {col: 'sum' for col in self.metric_cols}
        agg_dict['Risk_Score'] = 'max'; agg_dict['Total_Impact'] = 'sum'
        self.report_data = self.df.groupby(self.location_col).agg(agg_dict).reset_index()
        m = self.report_data['Risk_Score'].max()
        self.report_data['Risk_Index'] = (self.report_data['Risk_Score'] / m * 100) if m > 0 else 0
        self.report_data = self.report_data.sort_values('Risk_Index', ascending=False)
        
        avg = self.report_data['Risk_Index'].head(5).mean()
        t = STRATEGIC_ANALYSIS_TEMPLATES.get(self.context, STRATEGIC_ANALYSIS_TEMPLATES["DEFAULT"])
        if avg > 75: self.strategic_assessment = t["HIGH_RISK"]
        elif avg > 40: self.strategic_assessment = t["MODERATE_RISK"]
        else: self.strategic_assessment = t["LOW_RISK"]

    def run_anomaly_detection(self):
        print("🕵️ HUNTING FOR ANOMALIES...")
        features = self.report_data[['Risk_Score', 'Total_Impact']].values
        if len(features) < 5: return 
        iso = IsolationForest(contamination=0.05, random_state=42)
        self.report_data['Anomaly_Flag'] = iso.fit_predict(features)
        self.anomaly_count = len(self.report_data[self.report_data['Anomaly_Flag'] == -1])

    def run_nlp_topic_modeling(self):
        print("💬 RUNNING NLP ENGINE...")
        text_col = None; max_avg_len = 0
        for c in self.df.columns:
            if self.df[c].dtype == 'object' and c != self.location_col:
                avg = self.df[c].astype(str).str.len().mean()
                if avg > max_avg_len: max_avg_len = avg; text_col = c
        
        if text_col and max_avg_len > 3:
            try:
                tfidf = TfidfVectorizer(max_features=1000, stop_words='english')
                dtm = tfidf.fit_transform(self.df[text_col].astype(str))
                nmf = NMF(n_components=3, random_state=42, init='nndsvd').fit(dtm)
                feats = tfidf.get_feature_names_out()
                for i, topic in enumerate(nmf.components_):
                    top_words = [feats[j] for j in topic.argsort()[-5:]]
                    self.nlp_themes.append(f"THEME {i+1}: {', '.join(top_words).upper()}")
            except: self.nlp_themes.append("DATA INSUFFICIENT FOR NLP")
        else: self.nlp_themes.append("NO NARRATIVE FOUND")

    def run_network_analysis(self):
        print("🕸️ BUILDING OPTIMIZED SYNDICATE GRAPH...")
        features = self.report_data[self.metric_cols].values
        locations = self.report_data[self.location_col].values
        if len(features) < 2: return
        
        sim_matrix = cosine_similarity(features)
        G = nx.Graph()
        
        for i in range(len(locations)):
            for j in range(i + 1, len(locations)):
                sim_score = sim_matrix[i][j]
                if sim_score > 0.85:
                    G.add_edge(locations[i], locations[j], weight=sim_score)

        if not nx.is_empty(G):
            MST = nx.maximum_spanning_tree(G)
            for u, v, data in MST.edges(data=True):
                self.graph_links.append((u, v, data['weight']))
        
        print(f"   👉 OPTIMIZED TO {len(self.graph_links)} CLEAN CONNECTIONS.")

    def calculate_shifts(self):
        self.shift_split = SHIFT_PROFILES.get(self.context, SHIFT_PROFILES["DEFAULT"])

    def calculate_temporal_trends(self):
        if not self.year_col: return
        self.trend_data = self.df.groupby(self.year_col)['Risk_Score'].sum().reset_index().sort_values(self.year_col)
        if len(self.trend_data) > 1:
            x = np.arange(len(self.trend_data)); y = self.trend_data['Risk_Score'].values
            slope, _ = np.polyfit(x, y, 1)
            if slope > 50: self.trend_status = "CRITICAL ESCALATION (RISING)"
            elif slope > 0: self.trend_status = "MODERATE INCREASE"
            elif slope < 0: self.trend_status = "POSITIVE REDUCTION (FALLING)"

    def generate_orders(self):
        def get_order(row):
            if row.get('Anomaly_Flag') == -1: return "⚠️ STATISTICAL ANOMALY: SIU INVESTIGATION REQ."
            r = row['Risk_Index']; c = TACTICAL_COMMANDS.get(self.context, TACTICAL_COMMANDS["DEFAULT"])
            if r >= 80: tmpl = c["DEFCON_1"]
            elif r >= 50: tmpl = c["DEFCON_2"]
            elif r >= 20: tmpl = c["DEFCON_3"]
            else: tmpl = c["DEFCON_4"]
            try: return tmpl.format(location=str(row[self.location_col]).upper(), impact=row['Total_Impact'])
            except: return tmpl
        self.report_data['Tactical_Order'] = self.report_data.apply(get_order, axis=1)

    def run_simulation(self, pct):
        self.sim_strength = pct
        self.sim_deterrence = DETERRENCE_PHYSICS.get(self.context, 0.5)
        reduction = (pct / 100.0) * self.sim_deterrence
        if reduction > 0.95: reduction = 0.95
        self.report_data['Simulated_Risk'] = self.report_data['Risk_Index'] * (1 - reduction)
        self.report_data['Risk_Reduction'] = self.report_data['Risk_Index'] - self.report_data['Simulated_Risk']

    # --- ADDED: EXPORT FUNCTION FOR PKL ---
    def export_model(self, filename="tactical_brain.pkl"):
        """Saves the entire engine state to a PKL file for deployment."""
        print(f"💾 EXPORTING INTELLIGENCE MODEL TO: {filename}...")
        try:
            with open(filename, 'wb') as f:
                pickle.dump(self, f)
            print("✅ MODEL SAVED SUCCESSFULLY.")
        except Exception as e:
            print(f"❌ ERROR SAVING MODEL: {e}")

# ==============================================================================
#  MODULE C: DASHBOARD GENERATOR (HYBRID HUD EDITION)
# ==============================================================================
class DashboardGenerator:
    def __init__(self, engine):
        self.engine = engine # Store engine for accessing context/themes in build_map
        self.data = engine.report_data
        self.loc_col = engine.location_col
        self.context = engine.context
        self.total_recs = engine.total_records
        self.assessment = engine.strategic_assessment
        self.sim_pct = engine.sim_strength
        self.physics = engine.sim_deterrence
        self.trend_data = engine.trend_data
        self.trend_status = engine.trend_status
        self.year_col = engine.year_col
        self.shift_split = engine.shift_split
        self.anomalies = engine.anomaly_count
        self.themes = engine.nlp_themes
        self.links = engine.graph_links 

    def get_coords(self, loc):
        loc = str(loc).lower().strip()
        if loc in GEO_INTELLIGENCE: return GEO_INTELLIGENCE[loc]
        for k, v in GEO_INTELLIGENCE.items():
            if k in loc: return v
        return None

    def find_nearest_base(self, target_coords):
        min_dist = float('inf'); nearest_base_name = None; nearest_base_coords = None
        for name, base_coords in TACTICAL_BASES.items():
            dist = np.sqrt((target_coords[0]-base_coords[0])**2 + (target_coords[1]-base_coords[1])**2)
            if dist < min_dist: min_dist = dist; nearest_base_name = name; nearest_base_coords = base_coords
        return nearest_base_name, nearest_base_coords

    def get_osrm_route(self, start_coords, end_coords):
        url = f"http://router.project-osrm.org/route/v1/driving/{start_coords[1]},{start_coords[0]};{end_coords[1]},{end_coords[0]}?overview=full&geometries=geojson"
        try:
            r = requests.get(url, timeout=2)
            if r.status_code == 200: return r.json()['routes'][0]['geometry'], r.json()['routes'][0]['duration'] / 60
        except: return None, 0

    def generate_shift_chart(self):
        labels = ['MORNING', 'EVENING', 'NIGHT']; colors = ['#00e676', '#ffab00', '#2979ff']
        plt.figure(figsize=(6, 4), facecolor='#1e1e1e')
        plt.pie(self.shift_split, labels=labels, autopct='%1.0f%%', colors=colors, textprops={'color':"w"}, startangle=140, pctdistance=0.85)
        centre_circle = plt.Circle((0,0),0.70,fc='#1e1e1e'); fig = plt.gcf(); fig.gca().add_artist(centre_circle)
        plt.title(f"ROSTER: {self.context}", color='white')
        filename = "shift_chart.png"; plt.savefig(filename, bbox_inches='tight', dpi=100); plt.close()
        return os.path.abspath(filename)

    def generate_trend_chart(self):
        if self.trend_data is None: return None
        plt.figure(figsize=(10, 4), facecolor='#1e1e1e')
        plt.plot(self.trend_data[self.year_col].astype(str), self.trend_data['Risk_Score'], marker='o', color='#00e676', linewidth=2)
        plt.title(f"TREND: {self.trend_status}", color='white'); plt.grid(color='#333', linestyle='--'); plt.axis('off')
        filename = "trend_chart.png"; plt.savefig(filename, bbox_inches='tight', dpi=100); plt.close()
        return os.path.abspath(filename)

    def generate_network_chart(self):
        if not self.links: return None
        G = nx.Graph()
        for link in self.links: G.add_edge(link[0], link[1], weight=link[2])
        G.remove_nodes_from(list(nx.isolates(G)))
        if G.number_of_nodes() == 0: return None
        plt.figure(figsize=(10, 6), facecolor='#1e1e1e')
        pos = nx.kamada_kawai_layout(G) 
        nx.draw_networkx_nodes(G, pos, node_color='#00e5ff', node_size=600, alpha=0.9)
        nx.draw_networkx_edges(G, pos, edge_color='#555', width=1.5, alpha=0.5)
        nx.draw_networkx_labels(G, pos, font_color='white', font_size=8, font_family='sans-serif', font_weight='bold')
        plt.title("SYNDICATE BACKBONE (MAX SPANNING TREE)", color='white'); plt.axis('off')
        filename = "network_chart.png"; plt.savefig(filename, bbox_inches='tight', dpi=100); plt.close()
        return os.path.abspath(filename)

    def build_map(self, filename="tactical_map_v23.html"):
        print("🗺️ GENERATING TACTICAL MAP WITH HUD...")
        m = folium.Map(location=[22.59, 82.96], zoom_start=5, tiles='CartoDB dark_matter', zoom_control=False)
        
        # 1. ADD PULSING CSS
        pulse_css = """
        <style>
        .pulse-icon { background-color: rgba(255, 0, 0, 0.6); border-radius: 50%; box-shadow: 0 0 0 0 rgba(255, 0, 0, 1); animation: pulse-red 2s infinite; }
        @keyframes pulse-red { 0% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(255, 0, 0, 0.7); } 70% { transform: scale(1); box-shadow: 0 0 0 10px rgba(255, 0, 0, 0); } 100% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(255, 0, 0, 0); } }
        </style>
        """
        m.get_root().html.add_child(folium.Element(pulse_css))

        # 2. STANDARD V16 MAP LOGIC
        for name, coords in TACTICAL_BASES.items():
            folium.Marker(location=coords, popup=f"HQ: {name}", icon=folium.Icon(color='blue', icon='shield', prefix='fa')).add_to(m)

        for link in self.links:
            loc_a, loc_b, score = link
            coords_a = self.get_coords(loc_a); coords_b = self.get_coords(loc_b)
            if coords_a and coords_b:
                folium.PolyLine(locations=[coords_a, coords_b], color='#00e5ff', weight=2, opacity=0.5, dash_array='5, 10', popup=f"LINK: {loc_a} <-> {loc_b}").add_to(m)

        for _, row in self.data.iterrows():
            target_coords = self.get_coords(row[self.loc_col])
            if target_coords:
                risk = row['Risk_Index']; is_anomaly = (row['Anomaly_Flag'] == -1)
                
                # PULSING MARKER IF CRITICAL
                if is_anomaly or risk >= 80:
                    folium.Marker(location=target_coords, icon=folium.DivIcon(html=f"""<div class="pulse-icon" style="width: 20px; height: 20px;"></div>""")).add_to(m)
                    
                color = '#9c27b0' if is_anomaly else ('#ff0000' if risk >= 80 else ('#ff9900' if risk >= 50 else '#00ff00'))
                
                route_info = ""
                if risk >= 50 or is_anomaly:
                    base_name, base_coords = self.find_nearest_base(target_coords)
                    geometry, duration = self.get_osrm_route(base_coords, target_coords)
                    if geometry:
                        col = '#9c27b0' if is_anomaly else '#00e676'
                        folium.GeoJson(geometry, style_function=lambda x, c=col: {'color': c, 'weight': 2, 'opacity': 0.8}).add_to(m)
                        route_info = f"<br><b>🚑 DEPLOY:</b> {base_name}<br><b>⏱️ ETA:</b> {int(duration/60)}h {int(duration%60)}m"
                    else:
                        AntPath(locations=[base_coords, target_coords], color='red', weight=2, opacity=0.7).add_to(m)

                popup = f"""<div style="font-family:Arial; width:250px;"><h4 style="margin:0; color:{color}">{row[self.loc_col]}</h4><b>RISK:</b> {risk:.1f}%{route_info}<hr><div style="font-size:10px">{row['Tactical_Order']}</div></div>"""
                folium.CircleMarker(location=target_coords, radius=risk/10 + 5, color=color, fill=True, fill_color=color, popup=folium.Popup(popup, max_width=300)).add_to(m)

        # 3. HUD INJECTION (V21 UI)
        nlp_html = "".join([f"<li>{t}</li>" for t in self.themes[:3]])
        shift_html = f"M: {int(self.shift_split[0]*100)}% | E: {int(self.shift_split[1]*100)}% | N: {int(self.shift_split[2]*100)}%"
        
        hud_html = f"""
        <div style="
            position: fixed; top: 20px; right: 20px; width: 320px; 
            background: rgba(20, 20, 30, 0.85); backdrop-filter: blur(8px); 
            border-left: 4px solid #00e676; padding: 15px; color: white; 
            font-family: 'Segoe UI', sans-serif; z-index: 9999; border-radius: 8px;
            box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.37);
        ">
            <h3 style="margin:0; color:#00e676; letter-spacing:1px;">COMMAND CENTER</h3>
            <div style="font-size:11px; color:#aaa; margin-bottom:10px;">LIVE INTELLIGENCE FEED V23.0</div>
            
            <div style="display:grid; grid-template-columns: 1fr 1fr; gap:5px; margin-bottom:10px;">
                <div style="background:rgba(255,255,255,0.05); padding:5px; border-radius:3px;">
                    <div style="font-size:9px; color:#aaa;">CONTEXT</div>
                    <div style="font-weight:bold; font-size:12px;">{self.context}</div>
                </div>
                <div style="background:rgba(255,255,255,0.05); padding:5px; border-radius:3px;">
                    <div style="font-size:9px; color:#aaa;">TREND</div>
                    <div style="font-weight:bold; font-size:12px; color:#00e5ff;">{self.trend_status}</div>
                </div>
            </div>

            <h5 style="margin:10px 0 5px 0; color:#e1bee7;">💬 DETECTED PATTERNS</h5>
            <ul style="font-size:10px; padding-left:15px; margin:0; color:#ddd;">{nlp_html}</ul>

            <h5 style="margin:10px 0 5px 0; color:#ffab00;">🕒 WORKFORCE ROSTER</h5>
            <div style="font-size:10px; background:rgba(255,171,0,0.1); padding:5px; border-radius:3px; color:#ffab00;">{shift_html}</div>
            
            <div style="margin-top:15px; border-top:1px solid #444; padding-top:5px; text-align:center; font-size:9px; color:#666;">SECURE TERMINAL | SYSTEM ACTIVE</div>
        </div>
        """
        m.get_root().html.add_child(folium.Element(hud_html))

        m.save(filename); return os.path.abspath(filename)

    def generate_initial_report(self):
        timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
        crit_count = len(self.data[self.data['Risk_Index'] > 80])
        trend_path = self.generate_trend_chart(); shift_path = self.generate_shift_chart()
        network_path = self.generate_network_chart()
        
        trend_html = f'<img src="trend_chart.png" style="width:100%;">' if trend_path else ""
        shift_html = f'<img src="shift_chart.png" style="width:100%;">' if shift_path else ""
        network_html = f'<img src="network_chart.png" style="width:100%;">' if network_path else "<p style='color:#777'>No Strong Links Detected</p>"
        
        themes_html = ""
        for t in self.themes: themes_html += f"<li style='margin-bottom:5px; color:#e1bee7;'>{t}</li>"

        html = f"""
        <html><head><style>
            body {{ font-family: 'Segoe UI', sans-serif; background: #121212; color: #ddd; padding: 20px; }}
            .container {{ max-width: 1200px; margin: 0 auto; }}
            .header {{ border-left: 5px solid #00e5ff; padding: 20px; background: #1e1e1e; margin-bottom: 20px; }}
            .stats {{ display: grid; grid-template-columns: repeat(4, 1fr); gap: 15px; margin-bottom: 20px; }}
            .card {{ background: #1e1e1e; padding: 15px; border-top: 3px solid #333; }}
            .card h2 {{ margin: 5px 0 0 0; font-size: 1.8em; }}
            .box {{ background: #1e1e1e; padding: 20px; margin-bottom: 20px; }}
            table {{ width: 100%; border-collapse: collapse; background: #1e1e1e; }}
            th, td {{ padding: 10px; border-bottom: 1px solid #333; text-align: left; }}
            th {{ color: #00e5ff; background: #2c2c2c; }}
            .crit {{ color: #ff5252; font-weight: bold; }}
            .anom {{ color: #9c27b0; font-weight: bold; background: rgba(156, 39, 176, 0.1); padding: 2px 5px; border-radius: 4px; }}
        </style></head><body>
            <div class="container">
                <div class="header"><h1>TACTICAL INTELLIGENCE V23.0 (DEPLOYMENT)</h1><div>GENERATED: {timestamp}</div></div>
                
                <div class="stats">
                    <div class="card" style="border-color:#00e676"><h3>CONTEXT</h3><h2>{self.context}</h2></div>
                    <div class="card" style="border-color:#ff5252"><h3>CRITICAL</h3><h2>{crit_count}</h2></div>
                    <div class="card" style="border-color:#2979ff"><h3>TREND</h3><h2 style="font-size:1em">{self.trend_status}</h2></div>
                    <div class="card" style="border-color:#9c27b0"><h3>ANOMALIES</h3><h2>{self.anomalies}</h2></div>
                </div>

                <div class="box" style="border-left: 4px solid #00e5ff; background:#1a232e;">
                    <h3 style="margin-top:0; color:#00e5ff;">🕸️ SYNDICATE BACKBONE (OPTIMIZED GRAPH)</h3>
                    <p style="color:#aaa;">Showing only the strongest connections (Maximum Spanning Tree).</p>
                    {network_html}
                </div>

                <div class="box" style="border-left: 4px solid #e1bee7; background:#2a1a2e;">
                    <h3 style="margin-top:0; color:#e1bee7;">💬 NLP THEMES</h3>
                    <ul style="font-family:monospace;">{themes_html}</ul>
                </div>

                <div style="display:grid; grid-template-columns: 2fr 1fr; gap:20px;">
                    <div class="box" style="border-left: 4px solid #00e676;">{trend_html}</div>
                    <div class="box" style="border-left: 4px solid #ffab00;">{shift_html}</div>
                </div>

                <div class="box" style="border-left: 4px solid #fff;">
                    <h3 style="margin-top:0; color:#fff">⚠️ STRATEGIC ASSESSMENT</h3><p>{self.assessment}</p>
                </div>

                <table><thead><tr><th>ZONE</th><th>RISK</th><th>IMPACT</th><th>STATUS</th><th>TACTICAL ORDER</th></tr></thead><tbody>
        """
        for _, row in self.data.iterrows():
            r = row['Risk_Index']; cls = 'class="crit"' if r >= 80 else ''
            if row['Anomaly_Flag'] == -1: status_label = '<span class="anom">⚠️ ML ANOMALY</span>'
            elif r >= 80: status_label = '<span style="color:#ff5252">CRITICAL</span>'
            else: status_label = '<span style="color:#00e676">NORMAL</span>'
            html += f"""<tr><td><b>{row[self.loc_col]}</b></td><td><span {cls}>{r:.1f}%</span></td><td>{int(row['Total_Impact'])}</td><td>{status_label}</td><td style="font-size:11px; color:#aaa;">{row['Tactical_Order']}</td></tr>"""
        html += "</tbody></table></div></body></html>"
        filename = "1_Hybrid_Report.html"
        with open(filename, "w", encoding="utf-8") as f: f.write(html)
        return os.path.abspath(filename)

    def generate_simulated_report(self):
        avg_drop = self.data['Risk_Reduction'].mean()
        html = f"""<html><head><style>body {{ background:#121212; color:#ddd; font-family:'Segoe UI'; padding:20px; }} table{{width:100%; border-collapse:collapse;}} th,td{{padding:10px; border-bottom:1px solid #333;}} .drop{{color:#00e676;}}</style></head><body>
        <h1>SIMULATION RESULT</h1><h3>COMMANDER DECISION: +{self.sim_pct}% FORCE</h3><h3>PROJECTED REDUCTION: {avg_drop:.1f}%</h3>
        <table><tr><th>ZONE</th><th>OLD RISK</th><th>NEW RISK</th><th>REDUCTION</th></tr>"""
        for _, row in self.data.iterrows():
            html += f"""<tr><td>{row[self.loc_col]}</td><td>{row['Risk_Index']:.1f}%</td><td>{row['Simulated_Risk']:.1f}%</td><td class="drop">▼ -{row['Risk_Reduction']:.1f}%</td></tr>"""
        html += "</table></body></html>"
        filename = "2_Simulation_Result.html"
        with open(filename, "w", encoding="utf-8") as f: f.write(html)
        return os.path.abspath(filename)

# ==============================================================================
#  MAIN LOOP
# ==============================================================================
def main():
    root = tk.Tk(); root.withdraw(); root.attributes('-topmost', True)
    print("👇 Select Dataset...")
    path = filedialog.askopenfilename(title="SELECT CRIME DATASET")
    if not path: return

    ingest = DataIngestionUnit(path)
    if ingest.load_dataset():
        ingest.sanitize_columns()
        engine = CrimeAnalysisEngine(ingest.clean_data)
        engine.detect_context(); engine.map_columns(); engine.calculate_risk(); 
        engine.calculate_temporal_trends(); engine.calculate_shifts();
        engine.run_anomaly_detection() 
        engine.run_nlp_topic_modeling()
        engine.run_network_analysis() 
        engine.generate_orders()
        
        # --- EXPORT MODEL (PKL) ---
        engine.export_model("tactical_brain.pkl") 
        # --------------------------
        
        viz = DashboardGenerator(engine)
        map_path = viz.build_map("tactical_map_v23.html")
        rep_path = viz.generate_initial_report()
        
        print("\n📊 ANALYSIS READY.")
        webbrowser.open('file://' + map_path); webbrowser.open('file://' + rep_path)
        
        messagebox.showinfo("Commander's Station", "REVIEW REPORT.\nClick OK to Simulate.")
        user_input = simpledialog.askfloat("Tactical Decision", "Enter Force Surge % (0-100):", minvalue=0.0, maxvalue=100.0)
        if user_input is not None:
            engine.run_simulation(user_input)
            viz = DashboardGenerator(engine)
            sim_map = viz.build_map("tactical_map_simulated.html")
            sim_rep = viz.generate_simulated_report()
            print(f"\n🔮 SIMULATION COMPLETE.")
            webbrowser.open('file://' + sim_map); webbrowser.open('file://' + sim_rep)

if __name__ == "__main__":
    main()