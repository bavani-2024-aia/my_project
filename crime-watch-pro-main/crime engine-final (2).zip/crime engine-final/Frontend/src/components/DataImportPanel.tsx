import { useState, useRef } from 'react';
import axios from 'axios'; 
import { Upload, CheckCircle2, X, Loader2, Server, Globe, FileText, Activity } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { toast } from 'sonner';

interface AIResult {
  success: boolean;
  map_html: string;
  report_html: string;
  simulation_html: string;
  context: string;
  anomalies: number;
  trend: string;
  shift_roster: number[]; 
  strategic_assessment: string;
  data: any[];
}

interface DataImportPanelProps {
  onAnalysisComplete?: (result: any) => void;
}

const DataImportPanel = ({ onAnalysisComplete }: DataImportPanelProps) => {
  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [importedFile, setImportedFile] = useState<File | null>(null);
  const [intelligence, setIntelligence] = useState<AIResult | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const processFile = async (file: File) => {
    setImportedFile(file);
    setIsProcessing(true);
    setProgress(10);
    
    const formData = new FormData();
    formData.append('file', file);

    try {
      // 🚀 UNIVERSAL FIX: Auto-detects your IP address
      // If you are on 10.227.x.x, it connects to 10.227.x.x:5000
      // If you are on localhost, it connects to localhost:5000
      const currentHost = window.location.hostname;
      const apiUrl = `http://${currentHost}:5000/api/analyze`;
      
      console.log(`🔌 connecting to: ${apiUrl}`);

      const response = await axios.post(apiUrl, formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
        onUploadProgress: (e) => {
            const percent = Math.round((e.loaded * 100) / (e.total || 100));
            setProgress(percent < 100 ? percent / 2 : 60);
        }
      });

      if (response.data && response.data.success) {
        setProgress(100);
        setIntelligence(response.data); 
        if (onAnalysisComplete) onAnalysisComplete(response.data); 
        toast.success("Intelligence Received");
      }
    } catch (error: any) {
      console.error("❌ Error:", error);
      // Detailed error message for debugging
      let msg = "Connection Failed.";
      if (error.message === "Network Error") {
          msg = `Firewall Blocked! Ensure Python is running on Port 5000.`;
      }
      toast.error(msg);
      setProgress(0);
    } finally {
      setIsProcessing(false);
    }
  };

  const openView = (content: string) => {
    if (!content) return;
    const blob = new Blob([content], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    window.open(url, '_blank');
  };

  return (
    <div className="bg-card rounded-xl border border-border p-6 shadow-sm">
      <div className="flex justify-between items-center border-b pb-4 mb-4">
        <h3 className="font-semibold flex items-center gap-2">
          <Server className="h-4 w-4 text-blue-500" /> AI Import Terminal
        </h3>
        {/* Debug Indicator */}
        <span className="text-[10px] text-muted-foreground bg-secondary px-2 py-1 rounded">
            Target: {window.location.hostname}:5000
        </span>
      </div>
      
      {!importedFile ? (
        <div 
          onClick={() => fileInputRef.current?.click()}
          className="border-2 border-dashed rounded-lg p-10 cursor-pointer hover:border-blue-500/50 hover:bg-secondary/30 transition-all text-center group"
        >
          <div className="p-4 bg-primary/5 rounded-full w-fit mx-auto mb-4 group-hover:bg-primary/10 transition-colors">
            <Upload className="h-8 w-8 text-primary" />
          </div>
          <p className="font-medium text-lg">Click to Upload Crime CSV</p>
          <input ref={fileInputRef} type="file" accept=".csv" className="hidden" onChange={(e) => e.target.files?.[0] && processFile(e.target.files[0])} />
        </div>
      ) : (
        <div className="space-y-6">
            <div className="flex items-center gap-3 p-4 bg-secondary/20 rounded-lg border border-border">
                {isProcessing ? <Loader2 className="animate-spin text-blue-500" /> : <CheckCircle2 className="text-green-500" />}
                <div>
                    <p className="font-medium">{importedFile.name}</p>
                    <p className="text-xs text-muted-foreground">{isProcessing ? "Analyzing..." : "Ready"}</p>
                </div>
                {!isProcessing && (
                   <Button variant="ghost" size="icon" onClick={() => { setImportedFile(null); setIntelligence(null); }}>
                      <X className="h-4 w-4" />
                   </Button>
                )}
            </div>
            
            {isProcessing && <Progress value={progress} className="h-2" />}

            {/* TRINITY BUTTONS */}
            {intelligence && !isProcessing && (
                <div className="grid grid-cols-3 gap-2 mt-4 animate-in slide-in-from-bottom-2">
                    <Button onClick={() => openView(intelligence.map_html)} className="w-full bg-blue-600 hover:bg-blue-700 text-white">
                        <Globe className="mr-2 h-4 w-4" /> Open Map
                    </Button>
                    <Button onClick={() => openView(intelligence.report_html)} variant="outline" className="w-full">
                        <FileText className="mr-2 h-4 w-4" /> Report
                    </Button>
                    <Button onClick={() => openView(intelligence.simulation_html)} variant="outline" className="w-full">
                        <Activity className="mr-2 h-4 w-4" /> Sim
                    </Button>
                </div>
            )}
        </div>
      )}
    </div>
  );
};

export default DataImportPanel;