import { useState } from 'react';
import { searchCity, CityData, CrimeHotspot, CrimeType } from '@/data/crimeData';
import SearchBar from './SearchBar';
import StatsOverview from './StatsOverview';
import SimulationPanel from './SimulationPanel';
import PatrolRecommendations from './PatrolRecommendations';
import HotspotList from './HotspotList';
import ShiftAlertPanel from './ShiftAlertPanel';
import XAIExplanationPanel from './XAIExplanationPanel';
import SuggestedActionsPanel from './SuggestedActionsPanel';
import HumanOverridePanel from './HumanOverridePanel';
import CrimeMap from './CrimeMap';
import TimeRiskChart from './TimeRiskChart';
import DataImportPanel from './DataImportPanel'; 
import { MapPin, Radar, ExternalLink, Maximize2, FileText, Globe, Activity, LayoutDashboard } from 'lucide-react';

// LOCAL INTERFACE (Updated for the Trinity)
interface AIAnalysisResult {
  success: boolean;
  context: string;
  trend: string;
  nlp_themes: string[];
  anomalies: number;
  shift_roster: number[]; 
  strategic_assessment: string;
  map_html: string; 
  report_html: string;      // NEW
  simulation_html: string;  // NEW
  data: any[];
}

const Dashboard = () => {
  const [cityData, setCityData] = useState<CityData | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedHotspot, setSelectedHotspot] = useState<CrimeHotspot | null>(null);
  const [filterCrime, setFilterCrime] = useState<CrimeType | 'All'>('All');
  const [searchError, setSearchError] = useState<string | null>(null);
  const [intelligence, setIntelligence] = useState<AIAnalysisResult | null>(null);
  const [mapTimestamp, setMapTimestamp] = useState<number>(Date.now());
  
  // 🚀 TAB STATE: 'map' | 'report' | 'simulation'
  const [activeTab, setActiveTab] = useState<'map' | 'report' | 'simulation'>('map');

  const handleSearch = async (query: string) => {
    setIsLoading(true);
    setSearchError(null);
    setSelectedHotspot(null);
    setIntelligence(null); 
    
    await new Promise(resolve => setTimeout(resolve, 800));
    const result = searchCity(query);
    if (result) {
      setCityData(result);
      if(result.hotspots.length > 0) setSelectedHotspot(result.hotspots[0]);
    } else {
      setSearchError(`No data found for "${query}"`);
      setCityData(null);
    }
    setIsLoading(false);
  };

  const handleAnalysisComplete = (result: any) => {
    console.log("🚀 Dashboard Received Data:", result);
    if (!result) return;

    setIntelligence(result);
    setMapTimestamp(Date.now());
    setActiveTab('map'); // Reset to map on new upload

    const safeData = Array.isArray(result.data) ? result.data : [];
    const mappedHotspots: CrimeHotspot[] = safeData.map((row: any, i: number) => ({
        id: String(i),
        name: row?.Location || `Zone ${i}`,
        location: { lat: 11.0168 + (Math.random() * 0.05), lng: 76.9558 + (Math.random() * 0.05) },
        riskScore: Number(row?.Risk_Index) || 0,
        crimeCount: Number(row?.Total_Impact) || 0,
        trend: 'up',
        dominantCrime: result.context || "General"
    }));

    if (mappedHotspots.length > 0) {
        try {
            const riskiest = [...mappedHotspots].sort((a, b) => (b.riskScore || 0) - (a.riskScore || 0))[0];
            setSelectedHotspot(riskiest);
        } catch (e) { console.log(e); }
    }

    const roster = result.shift_roster || [0.33, 0.33, 0.33];

    setCityData({
        city: "AI INTELLIGENCE REPORT",
        hotspots: mappedHotspots,
        timeRisk: [
            { hour: 'Morning', risk: (roster[0] || 0) * 100 },
            { hour: 'Evening', risk: (roster[1] || 0) * 100 },
            { hour: 'Night',   risk: (roster[2] || 0) * 100 }
        ]
    });
  };

  const openFullScreenView = () => {
    let content = "";
    if (activeTab === 'map') content = intelligence?.map_html || "";
    if (activeTab === 'report') content = intelligence?.report_html || "";
    if (activeTab === 'simulation') content = intelligence?.simulation_html || "";

    if (content) {
      const blob = new Blob([content], { type: 'text/html' });
      const url = URL.createObjectURL(blob);
      window.open(url, '_blank');
    }
  };

  return (
    <div className="min-h-screen pt-16 bg-background text-foreground animate-in fade-in">
      
      {/* TOP BAR */}
      <div className="p-6 border-b border-border bg-card/30 grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
            <SearchBar onSearch={handleSearch} isLoading={isLoading} />
            {searchError && <p className="text-red-500 mt-2 text-center">{searchError}</p>}
        </div>
        <div className="lg:col-span-1">
            <DataImportPanel onAnalysisComplete={handleAnalysisComplete} />
        </div>
      </div>

      {!cityData ? (
        <div className="flex flex-col items-center justify-center min-h-[50vh] p-10">
          <div className="p-6 bg-secondary/20 rounded-full mb-4">
             <Radar className="h-16 w-16 text-primary" />
          </div>
          <h2 className="text-2xl font-bold">System Online</h2>
          <p className="text-muted-foreground mt-2">Ready for Data Upload</p>
        </div>
      ) : (
        <div className="p-6 space-y-6">
          
          <div className="flex items-center gap-3">
            <div className="p-2 bg-primary/10 rounded-lg"><MapPin className="text-primary" /></div>
            <h1 className="text-2xl font-bold">{cityData.city}</h1>
            {selectedHotspot && (
                <span className="px-3 py-1 rounded-full bg-red-500/10 text-red-500 text-xs font-mono border border-red-500/20 animate-pulse">
                    TARGET: {selectedHotspot.name}
                </span>
            )}
          </div>

          <StatsOverview 
            cityName={cityData.city}
            hotspots={cityData.hotspots || []}
            timeRisk={cityData.timeRisk || []}
            anomalyCount={intelligence?.anomalies || 0}
            context={intelligence?.context || "Standard"}
            trend={intelligence?.trend || "Stable"}
          />

          {/* 🚀 THE BIG VIEWPORT (Map / Report / Simulation) */}
          {intelligence ? (
            <div className="space-y-4">
                 
                 {/* TAB SWITCHER */}
                 <div className="flex gap-2">
                    <button 
                        onClick={() => setActiveTab('map')}
                        className={`px-4 py-2 rounded-lg flex items-center gap-2 font-medium transition-all ${activeTab === 'map' ? 'bg-primary text-white' : 'bg-card border hover:bg-secondary'}`}
                    >
                        <Globe className="h-4 w-4" /> Tactical Map
                    </button>
                    <button 
                        onClick={() => setActiveTab('report')}
                        className={`px-4 py-2 rounded-lg flex items-center gap-2 font-medium transition-all ${activeTab === 'report' ? 'bg-primary text-white' : 'bg-card border hover:bg-secondary'}`}
                    >
                        <FileText className="h-4 w-4" /> Mission Report
                    </button>
                    <button 
                        onClick={() => setActiveTab('simulation')}
                        className={`px-4 py-2 rounded-lg flex items-center gap-2 font-medium transition-all ${activeTab === 'simulation' ? 'bg-primary text-white' : 'bg-card border hover:bg-secondary'}`}
                    >
                        <Activity className="h-4 w-4" /> Simulation Deck
                    </button>
                 </div>

                 {/* MAIN VIEWPORT */}
                 <div className="w-full h-[650px] border-2 border-primary/20 rounded-xl overflow-hidden shadow-2xl relative bg-black">
                    <button 
                        onClick={openFullScreenView}
                        className="absolute top-4 right-4 z-10 bg-black/80 text-white px-3 py-1 rounded border border-white/20 flex items-center gap-2"
                    >
                        <Maximize2 className="h-4 w-4" /> Full Screen
                    </button>
                    
                    {/* Render active tab content via srcDoc */}
                    <iframe 
                        key={`${activeTab}-${mapTimestamp}`} // Forces refresh on tab switch
                        srcDoc={
                            activeTab === 'map' ? intelligence.map_html :
                            activeTab === 'report' ? intelligence.report_html :
                            intelligence.simulation_html
                        }
                        className="w-full h-full"
                        title="Main Viewport"
                        style={{ border: 'none', backgroundColor: '#f0f2f5' }}
                    />
                 </div>
            </div>
          ) : (
             /* Fallback Grid */
             <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
                <div className="xl:col-span-2 h-[500px] bg-card rounded-xl border border-border overflow-hidden">
                    <CrimeMap
                        hotspots={cityData.hotspots}
                        selectedHotspot={selectedHotspot}
                        onSelectHotspot={setSelectedHotspot}
                        filterCrime={filterCrime}
                        onFilterChange={setFilterCrime}
                    />
                </div>
                <div className="h-[500px]">
                    <TimeRiskChart timeRisk={cityData.timeRisk} />
                </div>
            </div>
          )}

          {/* BOTTOM PANELS */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
             <div className="lg:col-span-1">
                {selectedHotspot ? (
                    <SimulationPanel selectedHotspot={selectedHotspot} />
                ) : (
                    <div className="h-full flex items-center justify-center border rounded-xl bg-secondary/10 p-4 text-center text-muted-foreground">
                        Select a Zone to Run Risk Simulation
                    </div>
                )}
             </div>
             <div className="lg:col-span-1">
                <PatrolRecommendations hotspots={cityData.hotspots || []} />
             </div>
             <div className="lg:col-span-1">
                 <ShiftAlertPanel 
                    hotspots={cityData.hotspots} 
                    roster={intelligence?.shift_roster} 
                 />
             </div>
          </div>

          {/* XAI GRID */}
          {selectedHotspot && (
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div>
                  <XAIExplanationPanel 
                     hotspot={selectedHotspot} 
                     themes={intelligence?.nlp_themes} 
                     assessment={intelligence?.strategic_assessment}
                  />
                </div>
                <div><SuggestedActionsPanel hotspot={selectedHotspot} /></div>
                <div><HumanOverridePanel hotspot={selectedHotspot} /></div>
              </div>
          )}
        </div>
      )}
    </div>
  );
};

export default Dashboard;