import { AlertTriangle, Moon, Sun, Sunset } from 'lucide-react';

// The new interface expects the simple roster array from Python
interface ShiftAlertPanelProps {
  roster?: number[]; // [Morning%, Evening%, Night%]
  hotspots?: any[];  // Keep this for backward compatibility if needed
}

const ShiftAlertPanel = ({ roster = [0.33, 0.33, 0.33] }: ShiftAlertPanelProps) => {
  // Convert decimals (0.4) to percentages (40)
  const morningRisk = Math.round((roster[0] || 0) * 100);
  const eveningRisk = Math.round((roster[1] || 0) * 100);
  const nightRisk = Math.round((roster[2] || 0) * 100);

  // Find the highest risk shift
  const maxRisk = Math.max(morningRisk, eveningRisk, nightRisk);
  let highestShift = "Morning";
  if (eveningRisk === maxRisk) highestShift = "Evening";
  if (nightRisk === maxRisk) highestShift = "Night";

  return (
    <div className="bg-card rounded-xl border border-border overflow-hidden h-full">
      <div className="p-4 border-b border-border flex items-center gap-2 bg-amber-500/5">
        <AlertTriangle className="h-5 w-5 text-amber-500" />
        <h3 className="font-semibold">Shift Roster Recommendations</h3>
      </div>

      <div className="p-6 space-y-6">
        <div className="p-4 bg-secondary/30 rounded-lg border border-border text-center">
          <p className="text-sm text-muted-foreground mb-1">Recommended Surge Shift</p>
          <div className="text-2xl font-bold text-amber-500 uppercase tracking-widest">
            {highestShift} PATROL
          </div>
        </div>

        <div className="space-y-4">
          {/* Morning Bar */}
          <div className="space-y-1">
            <div className="flex justify-between text-sm">
              <span className="flex items-center gap-2"><Sun className="h-4 w-4 text-orange-400"/> Morning (06:00 - 14:00)</span>
              <span className="font-mono">{morningRisk}% Force</span>
            </div>
            <div className="h-2 bg-secondary rounded-full overflow-hidden">
              <div className="h-full bg-orange-400 transition-all duration-500" style={{ width: `${morningRisk}%` }} />
            </div>
          </div>

          {/* Evening Bar */}
          <div className="space-y-1">
            <div className="flex justify-between text-sm">
              <span className="flex items-center gap-2"><Sunset className="h-4 w-4 text-purple-400"/> Evening (14:00 - 22:00)</span>
              <span className="font-mono">{eveningRisk}% Force</span>
            </div>
            <div className="h-2 bg-secondary rounded-full overflow-hidden">
              <div className="h-full bg-purple-400 transition-all duration-500" style={{ width: `${eveningRisk}%` }} />
            </div>
          </div>

          {/* Night Bar */}
          <div className="space-y-1">
            <div className="flex justify-between text-sm">
              <span className="flex items-center gap-2"><Moon className="h-4 w-4 text-blue-400"/> Night (22:00 - 06:00)</span>
              <span className="font-mono">{nightRisk}% Force</span>
            </div>
            <div className="h-2 bg-secondary rounded-full overflow-hidden">
              <div className="h-full bg-blue-400 transition-all duration-500" style={{ width: `${nightRisk}%` }} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ShiftAlertPanel;