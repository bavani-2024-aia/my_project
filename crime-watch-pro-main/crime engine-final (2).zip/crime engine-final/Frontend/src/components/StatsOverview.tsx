import { CrimeHotspot, TimeRisk } from '@/data/crimeData';
import { MapPin, AlertTriangle, Clock, TrendingUp, Activity, ShieldAlert, Scan } from 'lucide-react';

interface StatsOverviewProps {
  cityName: string;
  hotspots: CrimeHotspot[];
  timeRisk: TimeRisk[];
  // 🚀 New AI Props (Optional)
  anomalyCount?: number;
  context?: string;
  trend?: string;
}

const StatsOverview = ({ 
  cityName, 
  hotspots = [], 
  timeRisk = [], 
  anomalyCount, 
  context, 
  trend 
}: StatsOverviewProps) => {

  // 🛡️ SAFETY CHECK 1: Prevent crash if array is empty
  const totalHotspots = hotspots?.length || 0;
  
  // 🛡️ SAFETY CHECK 2: Handle missing risk scores gracefully
  const criticalHotspots = hotspots?.filter(h => (h.riskScore || h.risk || 0) >= 80).length || 0;
  
  const avgRisk = totalHotspots > 0 
    ? Math.round(hotspots.reduce((a, b) => a + (b.riskScore || b.risk || 0), 0) / totalHotspots) 
    : 0;

  // 🛡️ SAFETY CHECK 3: Prevent 'reduce' crash on empty timeRisk
  const peakHour = timeRisk?.length > 0 
    ? timeRisk.reduce((a, b) => a.risk > b.risk ? a : b) 
    : { label: 'Analyzing...', risk: 0 };

  // 🧠 LOGIC: If AI Data exists, show AI Stats. Otherwise, show Standard Stats.
  const isAIMode = context && context !== "Standard";

  const stats = [
    {
      label: isAIMode ? 'Detected Context' : 'Hotspot Zones',
      value: isAIMode ? context : totalHotspots,
      subtext: isAIMode ? 'AI Classification' : `in ${cityName}`,
      icon: isAIMode ? Scan : MapPin,
      color: 'text-primary',
      bg: 'bg-primary/10',
    },
    {
      label: isAIMode ? 'Anomalies Detected' : 'Critical Areas',
      value: isAIMode ? anomalyCount : criticalHotspots,
      subtext: isAIMode ? 'Requires Investigation' : 'Risk > 80',
      icon: isAIMode ? ShieldAlert : AlertTriangle,
      color: 'text-red-400',
      bg: 'bg-red-500/10',
    },
    {
      label: isAIMode ? 'Predicted Trend' : 'Avg Risk Score',
      value: isAIMode ? trend : avgRisk,
      subtext: isAIMode ? 'Next 24 Hours' : 'Across all zones',
      icon: TrendingUp,
      color: avgRisk >= 60 ? 'text-orange-400' : 'text-amber-400',
      bg: avgRisk >= 60 ? 'bg-orange-500/10' : 'bg-amber-500/10',
    },
    {
      label: 'Peak Risk Time',
      value: peakHour.label,
      subtext: `${Math.round(peakHour.risk)}% risk`,
      icon: Clock,
      color: 'text-blue-400',
      bg: 'bg-blue-500/10',
    },
  ];

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
      {stats.map((stat, index) => (
        <div
          key={stat.label}
          className="stat-card p-4 bg-card rounded-xl border border-border animate-fade-in"
          style={{ animationDelay: `${index * 100}ms` }}
        >
          <div className="flex items-start justify-between mb-3">
            <div className={`p-2 rounded-lg ${stat.bg}`}>
              <stat.icon className={`h-5 w-5 ${stat.color}`} />
            </div>
          </div>
          {/* Font size adjustment for long text */}
          <div className={`font-bold font-mono ${stat.color} ${typeof stat.value === 'string' && stat.value.length > 10 ? 'text-lg' : 'text-2xl'}`}>
            {stat.value || 0}
          </div>
          <div className="text-sm font-medium mt-1">{stat.label}</div>
          <div className="text-xs text-muted-foreground">{stat.subtext}</div>
        </div>
      ))}
    </div>
  );
};

export default StatsOverview;